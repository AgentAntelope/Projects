Hi there TA!

Name: Sean Myers
Email: SeanMyers0608@gmail.com
Project 1
Report: Tables referenced in report are on Tables.pdf and report in AI_REPORT.docx
Heuristics Implemented:
	8-Puzzle:
		Manhatten Distance -- code found in eight_puzzle.py 40-74
		Tiles out of Place -- code found in eight_puzzle.py 75-87
		Column-Row -- code found in eight_puzzle.py 17-39
	Romanian Path Finding:
		Straight Line  -- Code found in search.py line 117
		Home brew (Basically min of straight line of the node and all of it's neighbors. It is a relaxed heuristic of straight line by giving the person a free flight to a connected place) -- romania_path.py

Run instructions: python driver.py

Changing 8-puzzle states for test to show 8-Puzzle is working: line 4 of driver.py
Changing 8-puzzle states for main search algorithms run: line 331 of search.py 

