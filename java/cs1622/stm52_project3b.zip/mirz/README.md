mini-java
=========

MINI JAVA

It's Java, but even less useful!
