class TypeChecking1 {
	public static void main(String[] args) {
		System.out.println(new Foo().Bar());
	}
}

class Foo {

    public int Moo(){
        return 1;
    }
	public int Bar() {
        int a;
		Doo = 1;
		Moo = 1;
        Foo = 1;
		return 0;
	}
}
