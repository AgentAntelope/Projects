Non-boolean operand for operator ! at line 23, character 39
Non-integer operand for operator < at line 23, character 42
Use of undefined identifier b at line 24, character 4
Use of undefined identifier b at line 27, character 4
