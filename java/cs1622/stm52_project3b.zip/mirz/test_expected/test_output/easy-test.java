Non-boolean operand for operator ! at line 23, character 37
Non-boolean operand for operator ! at line 23, character 37
Non-integer operand for operator < at line 23, character 40
Non-boolean operand for operator ! at line 23, character 37
Non-boolean operand for operator ! at line 23, character 37
Non-integer operand for operator < at line 23, character 40
Attempt to use boolean operator && on non-boolean operands at line 23, character 34
Non-boolean operand for operator ! at line 23, character 37
Non-boolean operand for operator ! at line 23, character 37
Non-integer operand for operator < at line 23, character 40
Non-boolean operand for operator ! at line 23, character 37
Non-boolean operand for operator ! at line 23, character 37
Non-integer operand for operator < at line 23, character 40
Attempt to use boolean operator && on non-boolean operands at line 23, character 34
Attempt to use boolean operator && on non-boolean operands at line 23, character 44
Non-boolean expression used as the condition of if statement at line 23, character 3
Use of undefined identifier b at line 24, character 4
Use of undefined identifier b at line 27, character 4
