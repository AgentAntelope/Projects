Type mismatch during assignment at line 17, character 8
Type mismatch during assignment at line 19, character 5
Type mismatch during assignment at line 20, character 5
Type mismatch during assignment at line 21, character 5
Type mismatch during assignment at line 22, character 5
