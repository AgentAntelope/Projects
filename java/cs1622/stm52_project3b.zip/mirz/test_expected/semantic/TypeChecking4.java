Attempt to call a non-method at line 14, character 8
Type mismatch during assignment at line 14, character 5
Attempt to call a non-method at line 15, character 8
Type mismatch during assignment at line 15, character 5
Attempt to call a non-method at line 16, character 11
Type mismatch during assignment at line 16, character 5
Attempt to call a non-method at line 17, character 8
Type mismatch during assignment at line 17, character 5
Attempt to call a non-method at line 18, character 11
Type mismatch during assignment at line 18, character 5
