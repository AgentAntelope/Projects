Non-boolean expression used as the condition of if statement at line 23, character 3
Non-boolean expression used as the condition of if statement at line 26, character 4
Non-boolean expression used as the condition of if statement at line 33, character 3
Non-boolean operand for operator ! at line 39, character 7
Non-boolean expression used as the condition of if statement at line 39, character 3
Non-boolean expression used as the condition of if statement at line 51, character 3
Non-integer operand for operator < at line 57, character 13
Non-boolean expression used as the condition of while statement at line 73, character 3
Non-boolean expression used as the condition of while statement at line 77, character 3
Non-boolean operand for operator ! at line 81, character 10
Non-boolean expression used as the condition of while statement at line 81, character 3
Non-boolean expression used as the condition of while statement at line 89, character 3
Non-integer operand for operator < at line 93, character 16
