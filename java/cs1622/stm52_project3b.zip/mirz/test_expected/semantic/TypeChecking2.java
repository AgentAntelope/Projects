Use of undefined identifier Moo at line 16, character 7
Invalid r-value, Moo is a Method, at line 16, character 3
Type mismatch during assignment at line 16, character 5
