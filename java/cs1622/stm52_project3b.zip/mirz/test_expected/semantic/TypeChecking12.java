Illegal use of keyword ‘this’ in static method at line 4, character 22
Call of method System.out.println does not match its declared signature at line 4, character 3
