Use of undefined identifier Doo at line 14, character 3
Invalid l-value, Moo is a method, at line 15, character 7
Invalid l-value, Foo is a class, at line 16, character 13
