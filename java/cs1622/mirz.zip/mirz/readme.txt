Project:
    Mini Java IR Generation/Type Checking

Authors:
    Sean Myers
    Joel Griffith

How to Build:
    make (make sure you have JFlex installed)

How to run:
    edit the input file to whatever you want, then run `make run`

Running our personal tests:
    We built a test suite for each type error. To run the test suite, just run `make test`
    Success means that it errored out as we expected.

