Length property only applies to arrays, line 16, character 10
Type mismatch during assignment at line 16, character 7
Length property only applies to arrays, line 18, character 10
Type mismatch during assignment at line 18, character 7
Length property only applies to arrays, line 19, character 10
Type mismatch during assignment at line 19, character 7
