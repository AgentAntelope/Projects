Non-boolean operand for operator && at line 17, character 18
Non-boolean operand for operator && at line 18, character 18
Non-boolean operand for operator && at line 19, character 21
Non-boolean operand for operator && at line 20, character 18
Non-boolean operand for operator && at line 22, character 18
Non-boolean operand for operator && at line 23, character 18
Non-boolean operand for operator && at line 24, character 18
Non-boolean operand for operator && at line 25, character 27
