Call of method add does not match its declared number of arguments at line 14, character 8
Call of method add does not match its declared number of arguments at line 15, character 8
Call of method add does not match its declared number of arguments at line 16, character 8
Call of method plusZero does not match its declared number of arguments at line 19, character 8
Call of method plusZero does not match its declared number of arguments at line 20, character 8
Call of method isTrue does not match its declared number of arguments at line 23, character 8
Call of method isTrue does not match its declared number of arguments at line 24, character 8
