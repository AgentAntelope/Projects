jflex pretty.flex
javac Main.java
java Main test_input.java
