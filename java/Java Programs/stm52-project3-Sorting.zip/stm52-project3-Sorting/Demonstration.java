//////////////////////////////////////////////////////////////////////
///
///  Contents: Compare Sorting Algorithms
///  Author:   John Aronis
///  Date:     December 2009
///
//////////////////////////////////////////////////////////////////////

import java.util.Arrays ;
import java.util.Date ;
import java.util.Random ;

public class Demonstration {

  public static int startLength = 1000 ;
  public static int incrementLength = 1000 ;
  public static int maximumElement = 100 ;

  public static void main(String[] args) {
    Integer[] A ;
    System.out.println("    LENGTH   SELECTION       MERGE       QUICK        JAVA") ;
    for (int length = startLength ; true ; length += incrementLength) {
      System.out.printf("%10d", length ) ;
      A = makeRandomArray(length,maximumElement) ;
      startTimer() ;
      SelectionSort.selectionSort(A) ;
      System.out.printf("%12d", getElapsedTime() ) ;
      A = makeRandomArray(length,maximumElement) ;
      startTimer() ;
      MergeSort.mergeSort(A) ;
      System.out.printf("%12d", getElapsedTime() ) ;
      A = makeRandomArray(length,maximumElement) ;
      startTimer() ;
      QuickSort.quicksort(A) ;
      System.out.printf("%12d", getElapsedTime() ) ;
      A = makeRandomArray(length,maximumElement) ;
      startTimer() ;
      Arrays.sort(A) ;
      System.out.printf("%12d", getElapsedTime() ) ;
      System.out.println() ;
      System.out.println() ;
    }
  }

  public static Integer[] makeRandomArray(int length, int maxElement) {
    Integer[] result = new Integer[length] ;
    Random generator = new Random() ;
    for (int i=0 ; i<length ; i++) {
      result[i] = Math.abs(generator.nextInt() % maxElement) ;
    }
    return result ;
  }

  public static void print(Integer[] A) {
    for (int i = 0 ; i < A.length ; i++) { System.out.print(A[i] + " ") ; }
    System.out.println() ;
  }

  public static long startTime ;
  public static void startTimer() { startTime = ( (new Date()).getTime() ) ; }
  public static long getElapsedTime() { return ( (new Date()).getTime() - startTime ) ; }

}

/// End-of-File
