Name: Sean Myers
Email: Stm52@pitt.edu
Assignment: Sorting
Turn in Date: 2-19-09
Instructions: Run the Demonstration, it is the same Demonstration given in the code you gave us with slightly different syntax to reflect the 3 separate classes.

Files: Demonstration.java, MergeSort.java, SelectionSort.java, QuickSort.java, Demonstration.class,MergeSort.class, SelectionSort.class, QuickSort.class,  README.txt

Problems: None

