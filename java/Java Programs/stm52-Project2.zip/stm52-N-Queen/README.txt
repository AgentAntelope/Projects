Name: Sean Myers
Email: Stm52@pitt.edu
Assignment: N-Queens
Turn in Date: 2-14-09
Instructions: Run the DemonstrationOne instead of the normal Demonstration given with the project. I named a few variables different which is about the only thing different.

Files: DemonstrationOne.java, NQueen.java, DemonstrationOne.class, NQueen.class, Run.bat (in case you run off windows, it makes it easier for command line), README.txt

Problems: The program finds all the solutions but the Recursive calls are quite odd. With pruning, there are nearly half as less calls than the demonstration program but without pruning there is nearly ten times as many calls as the demonstration program. They still find all the answers but just an odd note..