Name: Sean Myers
Email: Stm52@pitt.edu
Assignment: Graham Scan
Turn in Date: 3-8-09
Instructions: Run the DemonstrationConvexHull and it should work.

Files: DemonstrationConvexHull.java, Graph.java, ConvexHull.java Point.java, DemonstrationConvexHull.class, Graph.class, Point.Class, ConvexHull.class , README.txt

Problems: The program, in the end, runs perfectly. I used a different way to find the Hull which is a lot better than using Trig functions but in return I couldn't implement an efficient Sort and so it uses SelectionSort to sort them. 