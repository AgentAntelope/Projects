/** Automatically generated file. DO NOT MODIFY */
package edu.cs1635.stm52.translator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}