Project 1
Author Sean Myers

Problems with program (potential): When typing in the arguments, they should all work but 
Track Number is a little different. Either type it in like -track number "args"  or "track 
number "args". If you type in like...-track, more than likely my program will crash. Other 
than that, both should run perfectly.

