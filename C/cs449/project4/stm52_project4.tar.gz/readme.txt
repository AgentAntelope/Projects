Name: Sean Myers
email: seanmyers0608@gmail.com


Known Bugs:
Not sure if this is a bug or not, but after about 600-700 shuffles, my program starts injecting 0's into my array. This is odd because at no point is there a 0 in the original card deck that is being shuffled. Don't know how it is doing it, but yea..weird.

Other info:
-Name to look for is /sys/class/misc/cards and /dev/cards.