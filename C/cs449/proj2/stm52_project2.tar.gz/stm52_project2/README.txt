Name: Sean Myers (Iph)
email: Seanmyers0608@gmail.com (prefered) 
	stm52@pitt.edu

Instructions: All the docs SHOULD load, but I am using OpenOffice and set it to 97/2000. Just in case, I provided a .txt version if they don't open.

Bugs: None in MyStrings. Other than my inability to write out what I want to say correctly, all should be in order.
