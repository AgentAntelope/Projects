sudo rmmod petmem.ko
sudo insmod petmem.ko
sudo user/petmem 128
sudo user/test
